import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import {RouterModule,Routes} from '@angular/router';
import {DataService} from './services/data.service';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MyloginComponent } from './mylogin/mylogin.component';
import { DatabindComponent } from './databind/databind.component';
import { EventbindingComponent } from './eventbinding/eventbinding.component';
import { TwowaybindComponent } from './twowaybind/twowaybind.component';
import { YellowColorDirective } from './yellow-color.directive';
import { RedColorDirective } from './red-color.directive';
import { UserComponent } from './user/user.component';
import { HomeComponent } from './home/home.component';



const appRoutes: Routes = [
  { path: '', component:HomeComponent },
  { path: 'user', component:UserComponent },
  { path: 'mylogin', component:MyloginComponent },
  { path: 'databind', component:DatabindComponent },
  { path: 'eventbind', component:EventbindingComponent },
  { path: 'twowaybind', component:TwowaybindComponent}
 

];



@NgModule({
  declarations: [
    AppComponent,
    MyloginComponent,
    DatabindComponent,
    EventbindingComponent,
    TwowaybindComponent,
    YellowColorDirective,
    RedColorDirective,
    UserComponent,
    HomeComponent 
  ],
  imports: [
    RouterModule.forRoot(appRoutes),
    BrowserModule,
    FormsModule,
    AppRoutingModule
  ],
  providers: [DataService],
  bootstrap: [AppComponent]
})
export class AppModule { }
