import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-databind',
  templateUrl: './databind.component.html',
  styleUrls: ['./databind.component.css']
})
export class DatabindComponent implements OnInit {

  imageDisplay="https://static.euronews.com/articles/stories/03/39/11/44/880x495_cmsv2_72eabe35-c105-57e5-94cf-a0380c44f60a-3391144.jpg";

  hello="Hi Nikhil , I'm LION";
  sayHello(){
return this.hello;
  }

  constructor() { }

  ngOnInit() {
  }
}
