import { RedColorDirective } from './red-color.directive';

describe('RedColorDirective', () => {
  it('should create an instance', () => {
    const directive = new RedColorDirective();
    expect(directive).toBeTruthy();
  });
});
