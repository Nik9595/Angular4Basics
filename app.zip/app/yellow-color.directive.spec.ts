import { YellowColorDirective } from './yellow-color.directive';

describe('YellowColorDirective', () => {
  it('should create an instance', () => {
    const directive = new YellowColorDirective();
    expect(directive).toBeTruthy();
  });
});
