import { Directive , ElementRef} from '@angular/core';

@Directive({
  selector: '[appYellowColor]'
})
export class YellowColorDirective {

  constructor(element : ElementRef) { 
  element.nativeElement.style.color= "Yellow";
  }
}
